console.log("Check out the Dr.Eintein great Publications!!!");
function prnt(txt){
    console.log(txt);
}
const papers=[
    {
        "id":1,
        "title": "The Universe and Dr. Einstein",
        "year": 2005,
        "published": true
    
    },
    {
        "id":2,
        "title": "Einstein on politics",
        "year": 2013,
        "published": true
    },
    {
        "id":3,
        "title": "Einstein versus the physical review",
        "year": 2005,
        "published": true
    },
    {
        "id":4,
        "title": "Einstein on peace",
        "year": 2017,
        "published": true
    },
    {
        "id":5,
        "title": "Einstein: The life and times",
        "year": 2022,
        "author": "Ronald Clark",
        "published": false
    }
]

prnt(papers.length);
for(let paper of papers){
    prnt(paper.title);
    prnt(paper.year);
    prnt(paper.author);
    prnt(paper.published);
}

 const url='https://upadhayay.github.io/db.json'
 fetch(url)
  .then(function (response) {
    return response.json();
  })
  .then(function (data) {
    appendData(data);
  })
  .catch(function (err) {
    console.log(err);
  });

   function appendData(data) {
    var mainContainer = document.getElementById("papers");
    for (var i = 1; i < data.books.length; i++) 
    {
      var div = document.createElement("div");
      div.innerHTML =  "title" + data[i].title;
      div.innerHTML = data.books[i].year;
      div.innerHTML = data[i].published;
      mainContainer.appendChild(div);
       console.log(div);
     }
   }



